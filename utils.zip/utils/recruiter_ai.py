
from utils.llm import client
from utils.json_parser import parse_llm_json


def recruiter_analysis(resume_text, jd_text, score, grade, decision):

    # -------------------------------
    # Deterministic Grade & Decision
    # -------------------------------

   

    

    prompt = f"""
You are a Senior Technical Recruiter.

Resume:
{resume_text}

Job Description:
{jd_text}

Professional ATS Score:
{score:.2f}

Official ATS Grade:
{grade}

Official Hiring Decision:
{decision}

Your task is ONLY to generate:

1. recommendation
2. exactly 3 strengths
3. exactly 3 weaknesses
4. recruiter notes
5. recruiter_score (0-100)

IMPORTANT:

- Do NOT change the grade.
- Do NOT change the hiring decision.
- recruiter_score must be between 0 and 100.
- Return ONLY valid JSON.

Return exactly this JSON:

{{
    "recommendation": "",
    "strengths": [
        "",
        "",
        ""
    ],
    "weaknesses": [
        "",
        "",
        ""
    ],
    "notes": "",
    "recruiter_score": 85
}}
"""

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {
                "role": "system",
                "content": "Return ONLY valid JSON."
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0.2
    )

    recruiter = parse_llm_json(
        response.choices[0].message.content
    )

    # Always enforce our own grade & decision
    recruiter["grade"] = grade
    recruiter["decision"] = decision

    # Fallback if LLM doesn't return recruiter_score
    if "recruiter_score" not in recruiter:
        recruiter["recruiter_score"] = int(score)

    return recruiter