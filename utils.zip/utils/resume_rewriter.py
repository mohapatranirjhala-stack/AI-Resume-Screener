
from utils.llm import client
from utils.json_parser import parse_llm_json


def rewrite_resume(original_resume):

    prompt = f"""
You are an expert ATS Resume Writer.

Rewrite the following resume professionally.

Rules:

- Keep ALL information truthful.
- Never invent experience.
- Never invent projects.
- Never invent certifications.
- Never invent skills.
- Improve grammar.
- Improve formatting.
- Improve readability.
- Use recruiter-friendly language.
- Use strong action verbs.
- Improve ATS compatibility.
- Preserve every section.
- Return the resume in plain text.
- Do NOT use Markdown.
- Do NOT use code blocks.

Return ONLY valid JSON.

{{
    "rewritten_resume":"Complete rewritten resume"
}}

Resume:

{original_resume}
"""

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0.2
    )

    result = parse_llm_json(
        response.choices[0].message.content
    )

    if not isinstance(result, dict):
        return {
            "rewritten_resume": original_resume
        }

    if "rewritten_resume" not in result:
        result["rewritten_resume"] = original_resume

    return result